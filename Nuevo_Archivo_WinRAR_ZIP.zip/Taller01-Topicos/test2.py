from DAO.FacturaDaoImpl import FacturaDaoImpl
from Item.TipoItem import TipoItem
from deps.Cliente import Cliente
from Item.ItemImpl import ItemImpl

db = FacturaDaoImpl()
db.inicializar()
item = db.items[0]
a = item.calcTotal(4)
print(a)
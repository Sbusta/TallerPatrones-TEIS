ctura in facturas:
        pass
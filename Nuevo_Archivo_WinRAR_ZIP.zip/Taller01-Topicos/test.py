from DAO.FacturaDaoImpl import FacturaDaoImpl
from Item.TipoItem import TipoItem
from deps.Cliente import Cliente
from Item.ItemImpl import ItemImpl



db = FacturaDaoImpl()

ite = ItemImpl(1, 1, 'Televisor LG 30"', 1000000)
ite2 = ItemImpl(1, 2, 'Televisor Samsung 40" FullHD 1 Link por mega', 4000000)
ite3= ItemImpl(2, 3, 'Zapatos Ferragamo autografeados por Petro', 10000000)
ite4 = ItemImpl(2, 4, 'Crocs del Uribisimo', 20000)
ite5 = ItemImpl(3, 5, 'Traje camuflado con dos botas izquierdas', 100000)
ite6 = ItemImpl(4, 6, 'Motosierra para uso domestica perfecta para salidas al pueblo', 400000)
ite7 = ItemImpl(5, 7, "Tomate", 2000)
ite8 = ItemImpl(6, 8, "Maracuya", 2600)
ite9 = ItemImpl(7, 9, "Frijoles Cargamanto", 17000)

db.crearItems(ite)
db.crearItems(ite2)
db.crearItems(ite3)
db.crearItems(ite4)
db.crearItems(ite5)
db.crearItems(ite6)
db.crearItems(ite7)
db.crearItems(ite8)
db.crearItems(ite9)

